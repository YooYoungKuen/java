package ch02.sec01;

public class VariableInitializationExample {

	public static void main(String[] args) {

		int value = 30;
		
		int result = value + 10;
		
		System.out.println(result);
		
		
	}

}
