package ch01.sec11;

public class Calculator {

	public static void main(String[] args) {
		
		
		int x = 1;
		int y = 2;
		int result = x + y ;
		
		// 두 개의 값을 합한 결과
		System.out.println(result);
	}

}
