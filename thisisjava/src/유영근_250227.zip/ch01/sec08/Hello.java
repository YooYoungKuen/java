/**
 * author: YooYoungKeun
 * Date: 2025-02-27
 * Desc: 처음으로 자바 파일 만드는 예제
 */
package ch01.sec08;

public class Hello {

	public static void main(String[] args) {
		
			//출력
			System.out.println("Hello, Dolly");
			
			// 한줄 주석
			/*여러줄 주석
			 * 1번 줄
			 * 2번 줄
			 */
			/**
			 * Document 주석
			 */
	}

}
