package practice;

public class p_250227_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i1 = 22;
		int i2 = 11;
		int i3 = 33;
		System.out.println(i1+i2+i3); //예상출력 66  (출력확인 66)
		
		int world = 5;
		System.out.println(world); //예상출력  5	(출력확인 5)
		int a = 6;
		System.out.println(world+a);//예상출력 11	(출력확인 11)
		
		int world2 = 5;
		System.out.println(world2+5);//예상출력 10	(출력확인 10)
		
		int world3 = 5;
		System.out.println("world3"+5);//예상출력 world35 	(출력확인 world35)
		
		

	}

}
