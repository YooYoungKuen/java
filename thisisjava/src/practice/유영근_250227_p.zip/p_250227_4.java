package practice;

public class p_250227_4 {

	public static void main(String[] args) {
		// 다음 변수가 정상인지 잘못인지 판별하고 이유 설명
		
		int 3i = 5;  //변수이름은 첫번째 글자가 문자여야하는데 숫자이므로 변수 사용 못함
		int i3i = 5; //정상
		int _hello = 55;//특수문자도 문자이므로 사용가능?
		int hello = 5.3;//변수이름은 사용가능하나 int 는 정수형이므로 5.3을 사용하고 싶다면 
						//실수형 float이나 double 사용
		int i+j = 4; //특수문자는 $,_ 만 사용가능 변수 사용못함
		int public = 5; //public은 약속어 이므로 변수 사용 못함
		int i#2 = 5;//특수문자는 $,_ 만 사용가능 변수 사용못함
		int MyCatAge = 10; //첫글자가 소문자여야 하므로 변수명 사용 못함
		int Mycatage = 20; // 변수명 사용가능하나 카멜방식이 관례임
		public class mycat() {}// 약속어는 사용못함

}
