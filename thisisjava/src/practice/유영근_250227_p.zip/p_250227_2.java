package practice;

public class p_250227_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int a= 10;
		System.out.println(a); //예상출력 10  (출력확인 10)
		
		int b = 30;
		System.out.println(b); //예상출력 30   (출력확인 30)
		
		int b2 = 30;
		System.out.println(b2+10); //예상출력 40  (출력확인 40)
		
		int c = 30;
		System.out.println(c+c); //예상출력 60  (출력확인 60)
		
		int hello = 50;
		System.out.println(hello+c); //예상출력 80   (출력확인 80)
		
		int d = 30;
		d = 60;
		System.out.println(d); //예상출력 60  (출력확인 60)
	}

}
