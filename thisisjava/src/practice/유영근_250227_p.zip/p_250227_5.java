package practice;

public class p_250227_5 {

	public static void main(String[] args) {
		// a에 5,b에 10을 넣은 다음 a,b의 합을 화면에 출력하는 프로그램 만들기
		
		
	int a = 5;
	int b = 10;
	int result = a + b;
	
	System.out.println("a + b ="+ result );

	}

}
