package practice;

public class P_250304_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * 성적표를 출력해 주세요
		 */

		System.out.println("******************");
		System.out.println("*      성적표      *");
		System.out.println("******************");
		System.out.println("* 국어    50\t *");
		System.out.println("******************");
		System.out.println("* 영어    50\t *");
		System.out.println("******************");
		System.out.println("* 수학    50\t *");
		System.out.println("******************");
		System.out.println("* 컴퓨터 학과   홍길동*");
		System.out.println("******************");
	}

}
