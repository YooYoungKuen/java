package practice;

public class P_250304_10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		/*문장을 기술해서 예상 결과를 주석으로 기재 한 후 실행
		 * 
		 */
		
		int a=10;
		System.out.println(a);
		//예상결과 10 , 결과 ==> 10
		System.out.println("=====================");
		
		int b=30;
		System.out.println(b);
		//예상 결과 30 , 결과 ==> 30
		System.out.println("=====================");
		
		int c=30;
		System.out.println(c+10);
		//예상결과 40 , 결과 ==> 40
		System.out.println("=====================");
		
		int d=30;
		System.out.println(d+d);
		//예상결과 60 , 결과 ==> 60
		System.out.println("=====================");
		
		/*
		 * 변수 hello에 50을 넣고 해당 변수를 이용해서 80이 출력이 되도록 코딩
		 */
		
		int hello=50;
		int world=30;
		int result = hello+world;
		
		System.out.println("result="+result);
		System.out.println("=====================");
		
		/*아래의 문장을 기술해서 예상 결과를 주석으로 기재한 후 실행
		 */
		
		int e=30;
		e=60;
		System.out.println(e);
		//예상결과 60 , 결과 ==> 60
		
		System.out.println("=====================");
		
		int i1=22;
		int i2=11;
		int i3=33;
		System.out.println(i1+i2+i3);
		//예상결과 66 , 결과 ==> 66
		

		
		
	}

}
