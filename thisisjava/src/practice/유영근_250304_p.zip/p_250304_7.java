package practice;

public class p_250304_7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		/*
		 *System.out.print("1");
		 *System.out.print(" ");
		 *System.out.println("");
		 *System.out.print("2");
		 *System.out.print("3");
		 *만으로 아래와 같이 출력이 되게 해 주세요
		 *   1
		 *  12
		 * 123  
		 */
		
		System.out.print(" ");
		System.out.print(" ");
		System.out.print(" ");
		System.out.println("1");
		System.out.print(" ");
		System.out.print(" ");
		System.out.print("1");
		System.out.println("2");
		System.out.print(" ");
		System.out.print("1");
		System.out.print("2");
		System.out.print("3");
		
		System.out.println("");
		System.out.println("======================");
		
		/*
		 * System.out.print("*");
		 *System.out.println("");
	 	 *만으로 아래와 같이 출력이 되게 해 주세요
	 	 * ****
	 	 * ****
	 	 * ****
	 	 * ****
		 */
		
		System.out.print("*");
		System.out.print("*");
		System.out.print("*");
		System.out.println("*");
		System.out.print("*");
		System.out.print("*");
		System.out.print("*");
		System.out.println("*");
		System.out.print("*");
		System.out.print("*");
		System.out.print("*");
		System.out.println("*");
		System.out.print("*");
		System.out.print("*");
		System.out.print("*");
		System.out.print("*");
		
		System.out.println("");
		System.out.println("======================");
		
		/*
		 * System.out.print("*");
		 *System.out.println("");
	 	 *만으로 아래와 같이 출력이 되게 해 주세요
	 	 * *
	 	 * **
	 	 * ***
	 	 * ****
		 */
		System.out.println("*");
		System.out.print("*");
		System.out.println("*");
		System.out.print("*");
		System.out.print("*");
		System.out.println("*");
		System.out.print("*");
		System.out.print("*");
		System.out.print("*");
		System.out.print("*");
		
		System.out.println("");
		System.out.println("======================");
		
		/*
		 * System.out.print("*");
		 *System.out.println(" ");
		 *System.out.println("");
	 	 *만으로 아래와 같이 출력이 되게 해 주세요
	 	 *     *
	 	 *    **
	 	 *   ***
	 	 *  ****
		 */
		System.out.print(" ");
		System.out.print(" ");
		System.out.print(" ");
		System.out.print(" ");
		System.out.println("*");
		System.out.print(" ");
		System.out.print(" ");
		System.out.print(" ");
		System.out.print("*");
		System.out.println("*");
		System.out.print(" ");
		System.out.print(" ");
		System.out.print("*");
		System.out.print("*");
		System.out.println("*");
		System.out.print(" ");
		System.out.print("*");
		System.out.print("*");
		System.out.print("*");
		System.out.println("*");
		
		System.out.println("");
		System.out.println("======================");
		/*
		 * System.out.print("*");
		 *System.out.println(" ");
		 *System.out.println("");
	 	 *만으로 아래와 같이 출력이 되게 해 주세요
	 	 *     *
	 	 *    ***
	 	 *   *****
	 	 *    ***
	 	 *     *
		 */
		
		System.out.print(" ");
		System.out.print(" ");
		System.out.print("*");
		System.out.print(" ");
		System.out.println(" ");
		System.out.print(" ");
		System.out.print("*");
		System.out.print("*");
		System.out.print("*");
		System.out.println(" ");
		System.out.print("*");
		System.out.print("*");
		System.out.print("*");
		System.out.print("*");
		System.out.println("*");
		System.out.print(" ");
		System.out.print("*");
		System.out.print("*");
		System.out.print("*");
		System.out.println(" ");	
		System.out.print(" ");
		System.out.print(" ");
		System.out.print("*");
		System.out.print(" ");
		System.out.println(" ");
	}

}
