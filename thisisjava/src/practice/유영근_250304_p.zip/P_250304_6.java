package practice;

public class P_250304_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * 예상결과를 주석으로 기재한 후 실행
		 */
		
		System.out.println("1");
		System.out.println("2");
		System.out.println("3");
		/*예상결과 출력후 개행
		 * 1
		 * 2
		 * 3
		 */
		System.out.println("====================");
		
		System.out.print("1");
		System.out.print("2");
		System.out.print("3");
		/*예상결과 출력후 개행 안함
		 * 123
		 */
		System.out.println("");
		System.out.println("====================");
		
		System.out.print("hello");
		System.out.println(" World");
		System.out.println(" World");
		System.out.print("hello");
		/*예상결과
		 * hello World
		 *  World
		 * hello 
		 */
		System.out.println("");
		System.out.println("====================");
		
		System.out.print("12");
		System.out.println("34");
		System.out.println("56");
		/*예상결과
		 * 1234
		 * 56
		 */
		System.out.println("====================");
		/*
		 * 아래와 같이 출력이 나오도록 코딩해 주세요
		 * hello
		 * java
		 */
		
		System.out.println("hello");
		System.out.print("java");
		
		
		
		
	}

}
