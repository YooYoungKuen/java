package practice;

public class P_250304_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*본인의 정보를 출력하는 프로그램을 만들어 주세요. 이름, 이메일, 핸드폰 번호 등
		 * 명함으로 만들어 출력해 주세요
		 */
		
		String myName = "대표 유영근 YooYoungKeun";
		String myAddress = "Pyeongtaek";
		String myEmail = "yyk0915@nate.com";
		String myPhoneNumber = "010-9212-0589";
		
		System.out.println("이름:" + myName);
		System.out.println("주소:" + myAddress);
		System.out.println("Email:" + myEmail);
		System.out.println("myPhoneNumber:" + myPhoneNumber);
	}

}
