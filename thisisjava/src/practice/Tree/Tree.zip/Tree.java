package practice.Tree;

public class Tree {

	  //정적 필드 생성
	
	static String name(String name) { 
		return name;
	}

	static int growthTime(int growthTime) {
		return growthTime;
	}

	static int starRating(int starRating) {
		return starRating;
	}

	static int currentAmount(int currentAmount) {
		return currentAmount;
	}

	static int maxAmount(int maxAmount) { 
		return maxAmount;
	}

	static int price(int price) {
		return price;
	}

}


