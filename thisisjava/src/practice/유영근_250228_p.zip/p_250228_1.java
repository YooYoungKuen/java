/**
 * author: YooYoungKeun

 * Date: 2025-02-28
 
 * Desc: 250228 Practice
 */


package practice;

public class p_250228_1 {

	public static void main(String[] args) {
		
		String myName = "유영근";
		String myAge = "39";
		String myHeight = "163cm";
		
		System.out.println("이름:" + myName + ", 나이:" + myAge + ", 키:" + myHeight);
		
	}

}
