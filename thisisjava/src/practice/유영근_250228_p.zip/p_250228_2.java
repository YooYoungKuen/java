package practice;

public class p_250228_2 {

	public static void main(String[] args) {
		
		//아래 나열된 자료형이 무슨 자료형인지 설명
		
//		
//		10		//정수형  10
//		1.		//실수형  1.0 (소수점만 있으면 자동으로 double 타입 됨)
//		6F		//실수형 6.0   float 은 뒤에 F 혹은 f 를 붙여준다 float var = 6F;
//		23d		//실수형 23.0  (뒤에 D 혹은 d를 붙이면 double 타입이 됨)
//		14E10   // 양수로 공이 10개 인 자리 . 140000000000.0
//		'a'		// 문자형 char 'a' , 숫자로 변환하면 ASCII 코드 값 '97' ('a'의 유니코드 값)

	}

}


