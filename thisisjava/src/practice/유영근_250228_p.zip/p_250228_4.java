package practice;

public class p_250228_4 {

	public static void main(String[] args) {
		
		
		// 두개의 숫자를 입력받아 곱한 값을 출력하는 프로그램 만들어 주세요

		int a = 25;
		int b = 28;
		int result = a * b;
		
		System.out.println("result:" + result);
		
	}

}
