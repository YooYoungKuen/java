package Test;

import java.util.Scanner;

public class Test250310 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
		
//		int comArr[] = new int[3];
//		int userArr[] = new int[3];		
		Scanner scanner = new Scanner (System.in);
		System.out.print("숫자를 입력하세요:");
		String strA = scanner.nextLine();
		int userArr = Integer.parseInt(strA);

		
		int comArr = (int)(Math.random()*9+1);
		
	
		for (int i = 0; i <= 0; i++) {
			
			if(comArr == userArr) {
				System.out.println("안타입니다.");
				
			}else {
				System.out.println("아웃입니다.");		
	
			}
			
		}
		
		
		for (int j = 0; j < 3 ; j++) {
			
			int userArr1 = scanner.nextInt();
			System.out.print("숫자를 입력하세요:");
		}

	}

}
